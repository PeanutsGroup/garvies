<?php print render($message); ?>
