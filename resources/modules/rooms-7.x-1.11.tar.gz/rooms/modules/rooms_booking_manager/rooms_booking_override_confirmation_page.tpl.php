<?php print render($change_search); ?>
<?php print render($confirm_form); ?>
